from rest_framework import serializers
from .models import Department, Client, IncidentDetails, Product,IncidentHandling,Task,ClientDetail


class ClientFullSerializer(serializers.ModelSerializer):
    class Meta:
        model = Client
        fields = '__all__'

class ClientBasicSerializer(serializers.ModelSerializer):
    class Meta:
        model = Client
        fields = ['client_id', 'name', 'status']
        
class ClientDetailSerializer(serializers.ModelSerializer):
    pdf_file_url = serializers.SerializerMethodField()

    class Meta:
        model = ClientDetail
        fields = [ 'title', 'description', 'pdf_file', 'pdf_file_url']
        read_only_fields = ['pdf_file_url']

    def get_pdf_file_url(self, obj):
        """
        ✅ Returns the full URL of the uploaded PDF file.
        """
        request = self.context.get('request')
        if obj.pdf_file:
            return request.build_absolute_uri(obj.pdf_file.url)
        return None


#PRODUCT SERIALIZER
class ProductSerializer(serializers.ModelSerializer):
    clients = ClientFullSerializer(many=True, read_only=True)  # ✅ Nested client details in Product

    class Meta:
        model = Product
        fields = ['product_id', 'name', 'clients']
    


class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = '__all__'


# INCIDENT ALL DETAIL
        
class IncidentDetailsSerializer(serializers.ModelSerializer):

    class Meta:
        model = IncidentDetails
        fields = ['incident_id','title','description' ]


#IncidentHandling
class IncidentHandlingBasicSerializer(serializers.ModelSerializer):
    class Meta:
        model = IncidentHandling
        fields=['client_name','client_ref_id']

class IncidentHandlingFullSerializer(serializers.ModelSerializer):
    class Meta:
        model=IncidentHandling
        fields='__all__'
        
        
class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'