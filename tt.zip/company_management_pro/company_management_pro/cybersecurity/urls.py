from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_nested.routers import NestedSimpleRouter

# Import views
from adminpanel.views import AdminDashboardView
from hr.views import HRDashboardView
from technical.views import TechnicalDashboardView
from cybersecurity.views import CyberSecurityDashboardView
from sales.views import SalesDashboardView
from finance.views import AccountsDashboardView

from .views import (
    DepartmentViewSet, ClientViewSet, IncidentDetailsViewSet,
    ProductViewSet, IncidentHandlingBasicViewSet, IncidentHandlingFullViewSet,
    TaskViewSet, ClientDetailViewSet  # ✅ Added ClientDetailViewSet
)

# Main Router
router = DefaultRouter()
router.register(r'departments', DepartmentViewSet)
router.register(r'clients', ClientViewSet, basename='client')
router.register(r'incidents', IncidentDetailsViewSet, basename='incident')
router.register(r'products', ProductViewSet, basename='products')
router.register(r'incident-handling-basic', IncidentHandlingBasicViewSet, basename='incident-basic')
router.register(r'incident-handling-full', IncidentHandlingFullViewSet, basename='incident-full')
router.register(r'tasks', TaskViewSet, basename="task")

# First-Level Nested Router (Clients inside Products)
product_router = NestedSimpleRouter(router, r'products', lookup='product')
product_router.register(r'clients', ClientViewSet, basename='product-clients')

# Second-Level Nested Router (Incidents & Client Details under Clients inside Products)
client_router = NestedSimpleRouter(product_router, r'clients', lookup='client')
client_router.register(r'incident_details', IncidentDetailsViewSet, basename='client-incidents')
client_router.register(r'client-details', ClientDetailViewSet, basename='client-details')  # ✅ Added Client Details

urlpatterns = [
    path('', include(router.urls)),
    
    # Dashboards
    path('admin/', AdminDashboardView.as_view(), name='admin-dashboard'),
    path('hr/', HRDashboardView.as_view(), name='hr-dashboard'),
    path('technical/', TechnicalDashboardView.as_view(), name='technical-dashboard'),
    path('cyber-security/', CyberSecurityDashboardView.as_view(), name='cyber-security-dashboard'),
    path('sales/', SalesDashboardView.as_view(), name='sales-dashboard'),
    path('accounts/', AccountsDashboardView.as_view(), name='accounts-dashboard'),
    
    # Cybersecurity
    path('products/<int:product_pk>/clients/<int:pk>/', 
         ClientViewSet.as_view({'get': 'retrieve', 'put': 'update', 'delete': 'destroy'}), 
         name="product-client-detail"),
    
    path('products/<int:pk>/clients/', 
         ProductViewSet.as_view({'get': 'clients', 'post': 'add_client'}), 
         name="product-client-list"),
    
    # Include nested routers
    path('api/cybersecurity/', include(router.urls)),
    path('api/cybersecurity/', include(product_router.urls)),
    path('', include(client_router.urls)),  # ✅ Includes client-details API
]
