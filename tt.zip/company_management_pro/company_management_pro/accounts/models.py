from django.contrib.auth.models import AbstractUser
from django.db import models
from django.conf import settings

class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('hr', 'HR'),
        ('technical', 'Technical'),
        ('cyber_security', 'Cyber Security'),
        ('sales', 'Sales'),
        ('accounts', 'Accounts'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='technical')
    phone = models.CharField(max_length=15, blank=True, null=True)
