from django.apps import AppConfig

class CybersecurityConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cybersecurity'  # ✅ Make sure this is correct
