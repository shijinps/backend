from django.db import models
from accounts.models import CustomUser


class Client(models.Model):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]

    client_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active')
    

    def __str__(self):
        return f"{self.name} ({self.status})"
    
class ClientDetail(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="details")
    title = models.CharField(max_length=255)  # Example: "KYC"
    description = models.TextField()  # Example: "Start Date: ..., End Date: ..."
    pdf_file = models.FileField(upload_to='incident_pdfs/', blank=True, null=True)

    def __str__(self):
        return self.title


class Product(models.Model):
    product_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255, unique=True)
    clients = models.ManyToManyField('Client', related_name="products")

    def __str__(self):
        return self.name


class Department(models.Model):
    name = models.CharField(max_length=50)
    description = models.TextField()
    head = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, related_name='headed_department')

    def __str__(self):
        return self.name


# INCIDENT details
class IncidentDetails(models.Model):
    incident_id = models.AutoField(primary_key=True)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='incidents')  
    title=models.CharField(max_length=255,default="No title given")
    description = models.TextField(default="No description provided")

    
    def __str__(self):
        return self.title


class IncidentHandling(models.Model):  
    """Handles incidents from a management perspective"""
    
    client_name = models.CharField(max_length=255)  # Name of the client
    client_ref_id = models.AutoField(primary_key=True) 
    incident_summary = models.TextField()  # Changed from 'incident_details'
    action_taken = models.TextField()  # Changed from 'actions_taken'
    policy_modifications = models.TextField(blank=True, null=True)  # Changed from 'policy_change'

    def __str__(self):
        return f"Incident {self.client_ref_id} - {self.client_name}"
    
    
class Task(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    is_completed = models.BooleanField(default=False)
    assigned_to = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name="tasks")
    created_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name="created_tasks")
    department = models.ForeignKey(Department, on_delete=models.CASCADE, null=True, blank=True)
    due_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} - {'Completed' if self.is_completed else 'Incomplete'} (Cyber Security)"



