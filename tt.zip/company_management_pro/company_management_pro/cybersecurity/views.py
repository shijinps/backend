from rest_framework import viewsets, status
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser
from django.db.models import Count
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.decorators import action

from accounts.models import CustomUser
from .models import Department, Client, Product, IncidentDetails,IncidentHandling,Task,ClientDetail
from .serializers import (
    DepartmentSerializer, ClientBasicSerializer, 
    ClientFullSerializer, IncidentDetailsSerializer, ProductSerializer,
    IncidentHandlingFullSerializer,IncidentHandlingBasicSerializer,TaskSerializer,ClientDetailSerializer
)


# PRODUCT VIEWSET
class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

    # ✅ GET all clients for a specific product
    @action(detail=True, methods=['get'])
    def clients(self, request, pk=None):
        product = self.get_object()  # ✅ Fetch the product
        clients = product.clients.all()  # ✅ Get related clients
        serializer = ClientFullSerializer(clients, many=True)
        return Response(serializer.data)

    # ✅ POST (Create a full client inside a product)
    @action(detail=True, methods=['post'], serializer_class=ClientFullSerializer)
    def add_client(self, request, pk=None):
        product = self.get_object()  # Get the product instance
        serializer = ClientFullSerializer(data=request.data)  # Deserialize full client data
        if serializer.is_valid():
            client = serializer.save()  # Save the new client
            product.clients.add(client)  # ✅ Link client to the product
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    # ✅ GET basic client details
    @action(detail=True, methods=['get'])
    def basic(self, request, pk=None):
        """
        ✅ API: /products/{id}/clients/basic/
        Returns basic client details linked to a product.
        """
        product = self.get_object()  # ✅ Fetch the product
        clients = product.clients.all()  # ✅ Get related clients
        serializer = ClientBasicSerializer(clients, many=True)
        return Response(serializer.data)





class ClientViewSet(viewsets.ModelViewSet):
    """
    Handles CRUD operations for clients inside a product.
    """

    queryset = Client.objects.all()
    serializer_class = ClientFullSerializer

    def get_queryset(self):
        """
        Filters clients by product ID.
        """
        product_pk = self.kwargs.get('product_pk')
        return Client.objects.filter(products__product_id=product_pk)

    def retrieve(self, request, product_pk=None, pk=None):
        """
        ✅ GET a specific client inside a product.
        Endpoint: /products/{product_id}/clients/{client_id}/
        """
        client = get_object_or_404(self.get_queryset(), pk=pk)
        serializer = ClientFullSerializer(client)
        return Response(serializer.data)

    def update(self, request, product_pk=None, pk=None):
        """
        ✅ UPDATE a specific client inside a product.
        Endpoint: /products/{product_id}/clients/{client_id}/
        """
        client = get_object_or_404(self.get_queryset(), pk=pk)
        serializer = ClientFullSerializer(client, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, product_pk=None, pk=None):
        """
        ✅ DELETE a specific client inside a product.
        Endpoint: /products/{product_id}/clients/{client_id}/
        """
        product = get_object_or_404(Product, pk=product_pk)
        client = get_object_or_404(self.get_queryset(), pk=pk)
        product.clients.remove(client)  # ✅ Unlink the client from product
        return Response(status=status.HTTP_204_NO_CONTENT)



class ClientDetailViewSet(viewsets.ModelViewSet):
    """
    API for managing client details inside a product.
    """
    serializer_class = ClientDetailSerializer
    parser_classes = (MultiPartParser, FormParser)  # ✅ Supports file uploads

    def get_queryset(self):
        """
        ✅ Fetches details for a specific client inside a specific product.
        """
        product_pk = self.kwargs.get('product_pk')
        client_pk = self.kwargs.get('client_pk')
        return ClientDetail.objects.filter(client__client_id=client_pk, client__products__product_id=product_pk)

    def create(self, request, product_pk=None, client_pk=None):
        """
        ✅ Adds a new client detail under a product with a PDF file.
        Endpoint: /product/{product_id}/clients/{client_id}/client-details/
        """
        product = get_object_or_404(Product, pk=product_pk)
        client = get_object_or_404(Client, pk=client_pk, products=product)  # Ensure client belongs to the product

        # Handle file upload separately
        pdf_file = request.FILES.get('pdf_file', None)

        serializer = self.get_serializer(data=request.data)
        
        if serializer.is_valid():
            serializer.save(client=client, pdf_file=pdf_file)  # ✅ Save with file
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        """
        ✅ Deletes the client detail and removes the associated PDF file.
        """
        client_detail = self.get_object()
        
        # Delete the PDF file from storage if it exists
        if client_detail.pdf_file:
            client_detail.pdf_file.delete()

        return super().destroy(request, *args, **kwargs)


class CyberSecurityDashboardView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        return Response({"message": "Welcome to the Cyber Security Dashboard"}, status=status.HTTP_200_OK)

# DEPARTMENT VIEWSET
class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    permission_classes = [AllowAny]



# BASE DASHBOARD VIEW
class DashboardBaseView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        return Response({"message": "Access denied"}, status=status.HTTP_403_FORBIDDEN)



# CLIENT VIEWSET (CYBERSOL)

class IncidentDetailsViewSet(viewsets.ModelViewSet):
    serializer_class = IncidentDetailsSerializer

    def get_queryset(self):
        product_pk = self.kwargs.get('product_pk')
        client_pk = self.kwargs.get('client_pk')

        # Debug print to verify parameters
        print(f"Product PK: {product_pk}, Client PK: {client_pk}")

        # Modify the queryset filtering
        queryset = IncidentDetails.objects.filter(
            client__pk=client_pk,  # Use pk instead of id
            client__products__pk=product_pk  # Ensure product relationship
        )

        # Optional: Add debug logging
        if not queryset.exists():
            print("No incidents found for the given client and product")

        return queryset

    def perform_create(self, serializer):
        client_pk = self.kwargs.get('client_pk')
        
        # Fetch the client, raising 404 if not found
        client = get_object_or_404(Client, pk=client_pk)
        
        # Save the incident with the specific client
        serializer.save(client=client)

    def create(self, request, *args, **kwargs):
        try:
            return super().create(request, *args, **kwargs)
        except Exception as e:
            # Log the full error for debugging
            print(f"Error creating incident: {str(e)}")
            return Response({
                'error': 'Failed to create incident',
                'details': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)



#IncidentHandlingBasic
class IncidentHandlingBasicViewSet(viewsets.ModelViewSet):
    queryset=IncidentHandling.objects.all()
    serializer_class=IncidentHandlingBasicSerializer
    permission_classes=[AllowAny]
    

class IncidentHandlingFullViewSet(viewsets.ModelViewSet):
    queryset=IncidentHandling.objects.all()
    serializer_class=IncidentHandlingFullSerializer
    permission_classes=[AllowAny]
    

class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer

    def perform_create(self, serializer):
        serializer.save()  # Removed user assignment

    def perform_update(self, serializer):
        serializer.save()  # No user-based permission check

    def perform_destroy(self, instance):
        instance.delete()  # No role-based restrictions